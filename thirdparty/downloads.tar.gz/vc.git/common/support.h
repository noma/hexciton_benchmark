#ifndef VC_DEPRECATED_COMMON_SUPPORT_H
#define VC_DEPRECATED_COMMON_SUPPORT_H
#ifdef __GNUC__
#warning "the <Vc/common/support.h> header is deprecated. Use <Vc/support.h> instead."
#endif
#include <Vc/support.h>
#endif // VC_DEPRECATED_COMMON_SUPPORT_H
